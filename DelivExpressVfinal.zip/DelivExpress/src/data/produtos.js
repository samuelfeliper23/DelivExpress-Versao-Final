const produtos = [
    {
        id: 1,
        nome: 'X-Burguer',
        descricao: 'Pão, hambúrguer e queijo especial.',
        preco: 25.90,
        imagem: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500'
    },

    {
        id: 2,
        nome: 'X-Salada',
        descricao: 'Hambúrguer, queijo, alface, tomate e molho.',
        preco: 27.90,
        imagem: 'https://images.unsplash.com/photo-1550547660-d9450f859349?w=500'
    },

    {
        id: 3,
        nome: 'X-Bacon',
        descricao: 'Hambúrguer, queijo, bacon crocante e molho.',
        preco: 29.90,
        imagem: 'https://www.sabornamesa.com.br/receitas-de-lanches/x-bacon'
    },

    {
        id: 4,
        nome: 'Duplo Burger',
        descricao: 'Dois hambúrgueres, queijo e molho especial.',
        preco: 34.90,
        imagem: 'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=500'
    },

    {
        id: 5,
        nome: 'Batata Frita',
        descricao: 'Porção de batatas fritas crocantes.',
        preco: 18.90,
        imagem: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=500'
    },
];

export default produtos