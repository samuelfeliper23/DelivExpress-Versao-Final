import { StyleSheet } from 'react-native'

const cores = {
    primary: '#3D5AFE',
    second: '#2EC478',
    dark: '#202A44',
    secondary: '#464E5C',
    error: '#EB5757',
    background: '#F2F4F7' 
};

const styles = 
StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#ffffff',
    },

    header: {
        backgroundColor:
        cores.primary,
        paddingTop: 50,
        paddingBottom: 18,
        paddingHorizontal: 20,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },

    back: {
            color: '#ffffff',
            fontSize: 20,
            fontWeight:'bold',
        },

    item: {
            backgroundColor:
            cores.background,
            borderRadius: 14,
            padding: 16,
            marginBottom:12,
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center'
        },

    info: {
            flex: 1,
        },

    name: {
            color: cores.dark,
            fontSize: 17,
            fontWeight: 'bold',
        },

        price: {
            color: cores.secondary,
            fontSize: 14,
            marginTop: 5,
        },

        quantityContainer: {
            width: 44,
            height: 44,
            borderRadius: 10,
            backgroundColor: 
            cores.primary,
            alignItems: 'center',
            justifyContent: 'center'
        },

        quantityButtonText: {
            color: '#ffffff',
            fontSize: 18,
            fontWeight: 'bold',
            marginHorizontal: 14
        },

        summary: {
            marginTop: 10,
            padding: 18,
            borderRadius: 14,
            backgroundColor:
            cores.background
        },

        summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },

  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderTopWidth: 1,
    borderTopColor: '#D9DDE5',
    paddingTop: 14,
    marginTop: 4,
  },

  totalLabel: {
    color: cores.dark,
    fontSize: 20,
    fontWeight: 'bold',
  },

  total: {
    color: cores.primary,
    fontSize: 20,
    fontWeight: 'bold',
  },

  continueButton: {
    minHeight: 44,
    borderRadius: 10,
    backgroundColor: cores.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 18,
  },

  continueButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
    }

});

export default cores;