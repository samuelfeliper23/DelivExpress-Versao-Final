import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';

import { Picker } from '@react-native-picker/picker';

import cores from '../styles/cores';

const TAXA_ENTREGA = 6;

export default function Checkout({
  carrinho = [],
  voltarCarrinho,
  finalizarCheckout,
}) {
  // ==========================================
  // DADOS PESSOAIS
  // ==========================================

  const [nome, setNome] = useState('');
  const [telefone, setTelefone] = useState('');

  // ==========================================
  // ENDEREÇO
  // ==========================================

  const [cep, setCep] = useState('');
  const [endereco, setEndereco] = useState('');
  const [numero, setNumero] = useState('');
  const [complemento, setComplemento] = useState('');
  const [referencia, setReferencia] = useState('');

  // ==========================================
  // PAGAMENTO
  // ==========================================

  const [pagamento, setPagamento] = useState('');
  const [precisaTroco, setPrecisaTroco] = useState(false);
  const [trocoPara, setTrocoPara] = useState('');

  // ==========================================
  // ERRO
  // ==========================================

  const [erro, setErro] = useState('');

  // ==========================================
  // CÁLCULO DOS VALORES
  // ==========================================

  const subtotal = carrinho.reduce((total, item) => {
    const preco = Number(item.preco) || 0;
    const quantidade = Number(item.quantidade) || 0;

    return total + preco * quantidade;
  }, 0);

  const total = subtotal + TAXA_ENTREGA;

  // ==========================================
  // FORMATAÇÃO DE MOEDA
  // ==========================================

  const formatarMoeda = (valor) => {
    return Number(valor || 0).toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    });
  };

  // ==========================================
  // FINALIZAR PEDIDO
  // ==========================================

  const confirmarPedido = () => {
    setErro('');

    // Nome
    if (!nome.trim()) {
      setErro('Digite seu nome.');
      return;
    }

    // Telefone
    if (!telefone.trim()) {
      setErro('Digite seu telefone.');
      return;
    }

    if (telefone.length < 10) {
      setErro('Digite um telefone válido.');
      return;
    }

    // CEP
    if (!cep.trim()) {
      setErro('Digite seu CEP.');
      return;
    }

    if (cep.length !== 8) {
      setErro('CEP deve ter 8 dígitos.');
      return;
    }

    // Endereço
    if (!endereco.trim()) {
      setErro('Digite seu endereço.');
      return;
    }

    // Número
    if (!numero.trim()) {
      setErro('Digite o número do endereço.');
      return;
    }

    // Pagamento
    if (!pagamento) {
      setErro('Selecione uma forma de pagamento.');
      return;
    }

    // Troco
    if (pagamento === 'Dinheiro' && precisaTroco) {
      if (!trocoPara.trim()) {
        setErro('Informe o valor para o troco.');
        return;
      }
    }

    // Dados que serão enviados para o App.js
    const dadosPedido = {
      nome,
      telefone,
      cep,
      endereco,
      numero,
      complemento,
      referencia,
      pagamento,
      precisaTroco,
      trocoPara,
    };

    finalizarCheckout(dadosPedido);
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={
        Platform.OS === 'ios'
          ? 'padding'
          : undefined
      }
    >
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.conteudo}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >

        {/* ========================================
            CABEÇALHO
        ======================================== */}

        <View style={styles.cabecalho}>

          <TouchableOpacity
            style={styles.botaoVoltarTopo}
            onPress={voltarCarrinho}
          >
            <Text style={styles.textoVoltarTopo}>
              ← Dados de Entrega
            </Text>
          </TouchableOpacity>

        </View>

        {/* ========================================
            DADOS PESSOAIS
        ======================================== */}

        <View style={styles.card}>

          <Text style={styles.tituloCard}>
            Dados pessoais
          </Text>

          {/* NOME */}

          <Text style={styles.label}>
            Nome
          </Text>

          <TextInput
            style={styles.input}
            placeholder="Digite seu nome"
            placeholderTextColor="#9AA1AD"
            value={nome}
            onChangeText={setNome}
            maxLength={50}
          />

          {/* TELEFONE */}

          <Text style={styles.label}>
            Telefone
          </Text>

          <TextInput
            style={styles.input}
            placeholder="(19) 99999-9999"
            placeholderTextColor="#9AA1AD"
            value={telefone}
            onChangeText={setTelefone}
            keyboardType="phone-pad"
            maxLength={11}
          />

        </View>

        {/* ========================================
            ENDEREÇO
        ======================================== */}

        <View style={styles.card}>

          <Text style={styles.tituloCard}>
            Endereço de entrega
          </Text>

          {/* CEP */}

          <Text style={styles.label}>
            CEP
          </Text>

          <TextInput
            style={[
              styles.input,
              cep.length > 0 &&
                cep.length !== 8 &&
                styles.inputErro,
            ]}
            placeholder="00000000"
            placeholderTextColor="#9AA1AD"
            value={cep}
            onChangeText={(texto) => {
              // Permite somente números
              const somenteNumeros =
                texto.replace(/[^0-9]/g, '');

              setCep(somenteNumeros);
            }}
            keyboardType="numeric"
            maxLength={8}
          />

          {cep.length > 0 && cep.length !== 8 && (
            <Text style={styles.mensagemErro}>
              ⚠ CEP deve ter 8 dígitos.
            </Text>
          )}

          {/* ENDEREÇO */}

          <Text style={styles.label}>
            Endereço
          </Text>

          <TextInput
            style={styles.input}
            placeholder="Rua, Avenida..."
            placeholderTextColor="#9AA1AD"
            value={endereco}
            onChangeText={setEndereco}
            maxLength={100}
          />

          {/* NÚMERO */}

          <Text style={styles.label}>
            Número
          </Text>

          <TextInput
            style={styles.input}
            placeholder="Número"
            placeholderTextColor="#9AA1AD"
            value={numero}
            onChangeText={setNumero}
            keyboardType="numeric"
            maxLength={5}
          />

          {/* COMPLEMENTO */}

          <Text style={styles.label}>
            Complemento
          </Text>

          <TextInput
            style={styles.input}
            placeholder="Apartamento, casa..."
            placeholderTextColor="#9AA1AD"
            value={complemento}
            onChangeText={setComplemento}
            maxLength={50}
          />

          {/* REFERÊNCIA */}

          <Text style={styles.label}>
            Referência
          </Text>

          <TextInput
            style={styles.input}
            placeholder="Perto de..."
            placeholderTextColor="#9AA1AD"
            value={referencia}
            onChangeText={setReferencia}
            maxLength={100}
          />

        </View>

        {/* ========================================
            PAGAMENTO
        ======================================== */}

        <View style={styles.card}>

          <Text style={styles.tituloCard}>
            Pagamento
          </Text>

          <Text style={styles.label}>
            Forma de pagamento
          </Text>

          {/* SELECT DE PAGAMENTO */}

          <View style={styles.pickerContainer}>

            <Picker
              selectedValue={pagamento}
              onValueChange={(valor) => {
                setPagamento(valor);

                // Se não for dinheiro,
                // remove a opção de troco
                if (valor !== 'Dinheiro') {
                  setPrecisaTroco(false);
                  setTrocoPara('');
                }
              }}
              style={styles.picker}
              dropdownIconColor={cores.primary}
            >

              <Picker.Item
                label="Selecione uma forma de pagamento"
                value=""
              />

              <Picker.Item
                label="Cartão"
                value="Cartão"
              />

              <Picker.Item
                label="Pix"
                value="Pix"
              />

              <Picker.Item
                label="Dinheiro"
                value="Dinheiro"
              />

            </Picker>

          </View>

          {/* ====================================
              TROCO
          ==================================== */}

          {pagamento === 'Dinheiro' && (
            <View style={styles.trocoArea}>

              <TouchableOpacity
                style={styles.trocoOpcao}
                onPress={() =>
                  setPrecisaTroco(!precisaTroco)
                }
                activeOpacity={0.7}
              >

                <View
                  style={[
                    styles.checkbox,
                    precisaTroco &&
                      styles.checkboxSelecionado,
                  ]}
                >
                  {precisaTroco && (
                    <Text style={styles.check}>
                      ✓
                    </Text>
                  )}
                </View>

                <Text style={styles.textoTroco}>
                  Preciso de troco
                </Text>

              </TouchableOpacity>

              {precisaTroco && (
                <>
                  <Text style={styles.label}>
                    Troco para
                  </Text>

                  <TextInput
                    style={styles.input}
                    placeholder="Ex.: 50"
                    placeholderTextColor="#9AA1AD"
                    value={trocoPara}
                    onChangeText={(texto) => {
                      const somenteNumeros =
                        texto.replace(
                          /[^0-9.,]/g,
                          ''
                        );

                      setTrocoPara(
                        somenteNumeros
                      );
                    }}
                    keyboardType="decimal-pad"
                    maxLength={8}
                  />
                </>
              )}

            </View>
          )}

        </View>

        {/* ========================================
            RESUMO DO PEDIDO
        ======================================== */}

        <View style={styles.card}>

          <Text style={styles.tituloCard}>
            Resumo do pedido
          </Text>

          {/* PRODUTOS */}

          {carrinho.map((item, index) => {

            const preco =
              Number(item.preco) || 0;

            const quantidade =
              Number(item.quantidade) || 0;

            return (
              <View
                key={item.id ?? index}
                style={styles.item}
              >

                <Text style={styles.nomeItem}>
                  {quantidade}x {item.nome}
                </Text>

                <Text style={styles.precoItem}>
                  {formatarMoeda(
                    preco * quantidade
                  )}
                </Text>

              </View>
            );
          })}

          <View style={styles.divisor} />

          {/* SUBTOTAL */}

          <View style={styles.linha}>

            <Text style={styles.textoLinha}>
              Subtotal
            </Text>

            <Text style={styles.valor}>
              {formatarMoeda(subtotal)}
            </Text>

          </View>

          {/* ENTREGA */}

          <View style={styles.linha}>

            <Text style={styles.textoLinha}>
              Taxa de entrega
            </Text>

            <Text style={styles.valor}>
              {formatarMoeda(TAXA_ENTREGA)}
            </Text>

          </View>

          <View style={styles.divisor} />

          {/* TOTAL */}

          <View style={styles.linha}>

            <Text style={styles.totalTexto}>
              Total
            </Text>

            <Text style={styles.totalValor}>
              {formatarMoeda(total)}
            </Text>

          </View>

        </View>

        {/* ========================================
            ERRO
        ======================================== */}

        {erro !== '' && (
          <View style={styles.erroContainer}>

            <Text style={styles.textoErro}>
              {erro}
            </Text>

          </View>
        )}

        {/* ========================================
            FINALIZAR PEDIDO
        ======================================== */}

        <TouchableOpacity
          style={styles.botaoFinalizar}
          onPress={confirmarPedido}
          activeOpacity={0.8}
        >

          <Text style={styles.textoBotaoFinalizar}>
            Finalizar pedido
          </Text>

        </TouchableOpacity>

      </ScrollView>
    </KeyboardAvoidingView>
  );
}

// ======================================================
// ESTILOS
// ======================================================

const styles = StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: cores.background,
  },

  scroll: {
    flex: 1,
  },

  conteudo: {
    paddingHorizontal: 20,
    paddingTop: 18,
    paddingBottom: 40,
  },

  // ==========================================
  // CABEÇALHO
  // ==========================================

  cabecalho: {
    marginBottom: 15,
  },

  botaoVoltarTopo: {
    backgroundColor: cores.primary,
    borderRadius: 10,

    paddingVertical: 11,
    paddingHorizontal: 15,

    alignSelf: 'flex-start',
  },

  textoVoltarTopo: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: 'bold',
  },

  // ==========================================
  // CARDS
  // ==========================================

  card: {
    backgroundColor: '#FFFFFF',

    borderRadius: 14,

    padding: 16,

    marginBottom: 14,

    elevation: 2,

    shadowColor: '#000000',

    shadowOffset: {
      width: 0,
      height: 2,
    },

    shadowOpacity: 0.08,

    shadowRadius: 4,
  },

  tituloCard: {
    fontSize: 17,

    fontWeight: 'bold',

    color: cores.dark,

    marginBottom: 15,
  },

  // ==========================================
  // INPUTS
  // ==========================================

  label: {
    fontSize: 13,

    fontWeight: '600',

    color: cores.secondary,

    marginBottom: 6,
  },

  input: {
    height: 46,

    borderWidth: 1,

    borderColor: '#C9CED8',

    borderRadius: 9,

    backgroundColor: '#FFFFFF',

    paddingHorizontal: 12,

    fontSize: 14,

    color: cores.dark,

    marginBottom: 13,
  },

  inputErro: {
    borderColor: cores.error,

    backgroundColor: '#FFF5F5',
  },

  mensagemErro: {
    color: cores.error,

    fontSize: 12,

    marginTop: -8,

    marginBottom: 13,
  },

  // ==========================================
  // PICKER
  // ==========================================

  pickerContainer: {
    height: 48,

    borderWidth: 1,

    borderColor: '#C9CED8',

    borderRadius: 9,

    backgroundColor: '#FFFFFF',

    justifyContent: 'center',

    overflow: 'hidden',

    marginBottom: 5,
  },

  picker: {
    width: '100%',

    color: cores.dark,
  },

  // ==========================================
  // TROCO
  // ==========================================

  trocoArea: {
    marginTop: 12,
  },

  trocoOpcao: {
    flexDirection: 'row',

    alignItems: 'center',

    marginBottom: 12,
  },

  checkbox: {
    width: 20,
    height: 20,

    borderWidth: 2,

    borderColor: '#AAB0BA',

    borderRadius: 5,

    marginRight: 9,

    alignItems: 'center',

    justifyContent: 'center',
  },

  checkboxSelecionado: {
    backgroundColor: cores.primary,

    borderColor: cores.primary,
  },

  check: {
    color: '#FFFFFF',

    fontSize: 13,

    fontWeight: 'bold',
  },

  textoTroco: {
    fontSize: 14,

    color: cores.dark,
  },

  // ==========================================
  // RESUMO
  // ==========================================

  item: {
    flexDirection: 'row',

    justifyContent: 'space-between',

    alignItems: 'center',

    paddingVertical: 5,
  },

  nomeItem: {
    flex: 1,

    fontSize: 14,

    color: cores.dark,

    marginRight: 10,
  },

  precoItem: {
    fontSize: 14,

    fontWeight: '600',

    color: cores.dark,
  },

  divisor: {
    height: 1,

    backgroundColor: '#E5E7EB',

    marginVertical: 11,
  },

  linha: {
    flexDirection: 'row',

    justifyContent: 'space-between',

    alignItems: 'center',

    paddingVertical: 4,
  },

  textoLinha: {
    fontSize: 13,

    color: cores.secondary,
  },

  valor: {
    fontSize: 13,

    color: cores.dark,
  },

  totalTexto: {
    fontSize: 17,

    fontWeight: 'bold',

    color: cores.dark,
  },

  totalValor: {
    fontSize: 18,

    fontWeight: 'bold',

    color: cores.second,
  },

  // ==========================================
  // ERRO
  // ==========================================

  erroContainer: {
    backgroundColor: '#FFF0F0',

    borderWidth: 1,

    borderColor: '#F5BABA',

    borderRadius: 9,

    padding: 11,

    marginBottom: 12,
  },

  textoErro: {
    color: cores.error,

    fontSize: 13,

    textAlign: 'center',

    fontWeight: '500',
  },

  // ==========================================
  // BOTÃO FINALIZAR
  // ==========================================

  botaoFinalizar: {
    backgroundColor: cores.primary,

    borderRadius: 11,

    minHeight: 52,

    alignItems: 'center',

    justifyContent: 'center',

    marginTop: 2,
  },

  textoBotaoFinalizar: {
    color: '#FFFFFF',

    fontSize: 16,

    fontWeight: 'bold',
  },

});