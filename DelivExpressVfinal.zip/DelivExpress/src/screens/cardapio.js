import React from 'react';
import { View, Text, Image, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';

import produtos from '../data/produtos';
import colors from '../styles/cores';

// Paleta de cores da especificação
const cores = {
  primaria: colors?.primaria || '#3D5AFE',
  sucesso: colors?.sucesso || '#2EC478',
  escuro: colors?.escuro || '#202A44',
  secundario: colors?.secundario || '#464E5C',
  fundoCard: '#FFFFFF',
  fundoTela: '#F5F5F5',
};

// Componente do Card Individual do Lanche
function CardLanche({ item, onAdicionar }) {
  return (
    <View style={styles.card}>
      <Image source={{ uri: item.imagem }} style={styles.imagem} />

      <View style={styles.infoContainer}>
        <Text style={styles.nome}>{item.nome}</Text>
        <Text style={styles.descricao} numberOfLines={2}>
          {item.descricao}
        </Text>
        <Text style={styles.preco}>
          {item.preco.toLocaleString('pt-BR', {
            style: 'currency',
            currency: 'BRL',
          })}
        </Text>
      </View>

      <TouchableOpacity
        style={styles.botaoAdicionar}
        onPress={() => onAdicionar(item)}
        activeOpacity={0.7}
      >
        <Text style={styles.textoBotao}>+ Add</Text>
      </TouchableOpacity>
    </View>
  );
}

// Componente Principal da Tela de Cardápio
export default function Cardapio({ carrinho, adicionarAoCarrinho, irParaCarrinho }) {
  const totalItens = carrinho.reduce(
    (total, item) => total + item.quantidade,
    0
  );

  return (
    <View style={styles.container}>
      {/* Cabeçalho */}
      <View style={styles.header}>
        <View>
          <Text style={styles.logo}>DelivExpress</Text>
          <Text style={styles.subtitle}>Seu pedido, do seu jeito!</Text>
        </View>

        <TouchableOpacity
          style={styles.cartButton}
          onPress={irParaCarrinho}
          activeOpacity={0.7}
        >
          <Text style={styles.cartIcon}>🛒</Text>

          {totalItens > 0 && (
            <View style={styles.badge}>
              <Text style={styles.badgeText}>{totalItens}</Text>
            </View>
          )}
        </TouchableOpacity>
      </View>

      {/* Lista de produtos */}
      <ScrollView contentContainerStyle={styles.list}>
        <Text style={styles.title}>Cardápio</Text>

        {produtos.map((produto) => (
          <CardLanche
            key={produto.id}
            item={produto}
            onAdicionar={adicionarAoCarrinho}
          />
        ))}
      </ScrollView>
    </View>
  );
}

// Estilos Unificados
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: cores.fundoTela,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 40,
    paddingBottom: 16,
    backgroundColor: '#FFF',
    elevation: 2,
  },
  logo: {
    fontSize: 20,
    fontWeight: 'bold',
    color: cores.primaria,
  },
  subtitle: {
    fontSize: 12,
    color: cores.secundario,
  },
  cartButton: {
    position: 'relative',
    padding: 8,
  },
  cartIcon: {
    fontSize: 24,
  },
  badge: {
    position: 'absolute',
    right: 2,
    top: 2,
    backgroundColor: '#FF3B30',
    borderRadius: 10,
    minWidth: 18,
    height: 18,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 4,
  },
  badgeText: {
    color: '#FFF',
    fontSize: 10,
    fontWeight: 'bold',
  },
  list: {
    paddingBottom: 20,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: cores.escuro,
    marginHorizontal: 16,
    marginVertical: 16,
  },
  // Estilos do CardLanche
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: cores.fundoCard,
    padding: 12,
    marginVertical: 6,
    marginHorizontal: 16,
    borderRadius: 8,
    elevation: 2,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  imagem: {
    width: 60,
    height: 60,
    borderRadius: 8,
    marginRight: 12,
  },
  infoContainer: {
    flex: 1,
  },
  nome: {
    fontSize: 16,
    fontWeight: 'bold',
    color: cores.escuro,
  },
  descricao: {
    fontSize: 13,
    color: cores.secundario,
    marginVertical: 2,
  },
  preco: {
    fontSize: 15,
    fontWeight: 'bold',
    color: cores.primaria,
    marginTop: 2,
  },
  botaoAdicionar: {
    backgroundColor: cores.sucesso,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 6,
    minHeight: 44,
    justifyContent: 'center',
  },
  textoBotao: {
    color: '#FFF',
    fontWeight: 'bold',
    fontSize: 14,
  },
});