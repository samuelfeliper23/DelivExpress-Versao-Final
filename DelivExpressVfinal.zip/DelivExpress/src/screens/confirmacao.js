import React from 'react';

import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  StatusBar,
} from 'react-native';

import cores from '../styles/cores';

const TAXA_ENTREGA = 6;

export default function Confirmacao({
  pedido,
  carrinho = [],
  novoPedido,
}) {
  // ==========================================
  // FORMATAÇÃO DE VALORES
  // ==========================================

  const formatarMoeda = (valor) => {
    return Number(valor || 0).toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    });
  };

  // ==========================================
  // CÁLCULO DOS VALORES
  // ==========================================

  const subtotal = carrinho.reduce((total, item) => {
    const preco = Number(item.preco) || 0;
    const quantidade = Number(item.quantidade) || 0;

    return total + preco * quantidade;
  }, 0);

  const total = subtotal + TAXA_ENTREGA;

  // ==========================================
  // ENDEREÇO
  // ==========================================

  const enderecoCompleto = [
    pedido?.endereco,
    pedido?.numero,
    pedido?.complemento,
    pedido?.referencia,
    pedido?.cep,
  ]
    .filter(
      (parte) =>
        parte !== null &&
        parte !== undefined &&
        String(parte).trim() !== ''
    )
    .map((parte) => String(parte).trim())
    .join(', ');

  // ==========================================
  // CASO NÃO TENHA PEDIDO
  // ==========================================

  if (!pedido) {
    return (
      <View style={styles.erroContainer}>
        <Text style={styles.erroTitulo}>
          Nenhum pedido encontrado.
        </Text>

        <TouchableOpacity
          style={styles.botao}
          onPress={novoPedido}
        >
          <Text style={styles.textoBotao}>
            Voltar ao cardápio
          </Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>

      <StatusBar
        backgroundColor={cores.background}
        barStyle="dark-content"
      />

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.conteudo}
        showsVerticalScrollIndicator={false}
      >

        {/* ========================================
            CABEÇALHO
        ======================================== */}

        <View style={styles.cabecalho}>

          <View style={styles.iconeSucesso}>
            <Text style={styles.check}>
              ✓
            </Text>
          </View>

          <Text style={styles.titulo}>
            Pedido confirmado!
          </Text>

          <Text style={styles.subtitulo}>
            Seu pedido foi realizado com sucesso.
          </Text>

          <Text style={styles.numeroPedido}>
            Pedido #{pedido.numeroPedido}
          </Text>

        </View>

        {/* ========================================
            RESUMO DO PEDIDO
        ======================================== */}

        <View style={styles.card}>

          <Text style={styles.tituloCard}>
            Resumo do pedido
          </Text>

          {carrinho.map((item, index) => {
            const preco = Number(item.preco) || 0;
            const quantidade =
              Number(item.quantidade) || 0;

            return (
              <View
                key={item.id ?? index}
                style={styles.item}
              >

                <View style={styles.itemEsquerda}>

                  <Text style={styles.nomeItem}>
                    {quantidade}x {item.nome}
                  </Text>

                </View>

                <Text style={styles.precoItem}>
                  {formatarMoeda(
                    preco * quantidade
                  )}
                </Text>

              </View>
            );
          })}

          <View style={styles.divisor} />

          <View style={styles.linhaValor}>
            <Text style={styles.labelValor}>
              Subtotal
            </Text>

            <Text style={styles.valor}>
              {formatarMoeda(subtotal)}
            </Text>
          </View>

          <View style={styles.linhaValor}>
            <Text style={styles.labelValor}>
              Taxa de entrega
            </Text>

            <Text style={styles.valor}>
              {formatarMoeda(TAXA_ENTREGA)}
            </Text>
          </View>

          <View style={styles.divisor} />

          <View style={styles.totalContainer}>

            <Text style={styles.totalLabel}>
              Total pago
            </Text>

            <Text style={styles.totalValor}>
              {formatarMoeda(total)}
            </Text>

          </View>

        </View>

        {/* ========================================
            ENTREGA
        ======================================== */}

        <View style={styles.card}>

          <Text style={styles.tituloCard}>
            Entrega
          </Text>

          <Text style={styles.label}>
            Endereço
          </Text>

          <Text style={styles.informacao}>
            {enderecoCompleto ||
              'Endereço não informado'}
          </Text>

          {pedido.telefone ? (
            <>
              <Text style={styles.label}>
                Telefone
              </Text>

              <Text style={styles.informacao}>
                {pedido.telefone}
              </Text>
            </>
          ) : null}

        </View>

        {/* ========================================
            PAGAMENTO
        ======================================== */}

        <View style={styles.card}>

          <Text style={styles.tituloCard}>
            Pagamento
          </Text>

          <View style={styles.pagamentoLinha}>

            <Text style={styles.label}>
              Forma de pagamento
            </Text>

            <Text style={styles.pagamento}>
              {pedido.pagamento ||
                'Não informado'}
            </Text>

          </View>

          {pedido.pagamento === 'Dinheiro' &&
          pedido.precisaTroco ? (
            <View style={styles.pagamentoLinha}>

              <Text style={styles.label}>
                Troco para
              </Text>

              <Text style={styles.pagamento}>
                {formatarMoeda(
                  pedido.trocoPara
                )}
              </Text>

            </View>
          ) : null}

        </View>

        {/* ========================================
            BOTÃO
        ======================================== */}

        <TouchableOpacity
          style={styles.botao}
          onPress={novoPedido}
          activeOpacity={0.8}
        >
          <Text style={styles.textoBotao}>
            Fazer novo pedido
          </Text>
        </TouchableOpacity>

        <Text style={styles.rodape}>
          Obrigado por pedir com a DelivExpress!
        </Text>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({

  // ==========================================
  // CONTAINER
  // ==========================================

  container: {
    flex: 1,
    backgroundColor: cores.background,
  },

  scroll: {
    flex: 1,
  },

  conteudo: {
    paddingHorizontal: 20,
    paddingTop: 24,
    paddingBottom: 35,
  },

  // ==========================================
  // CABEÇALHO
  // ==========================================

  cabecalho: {
    alignItems: 'center',
    marginBottom: 20,
  },

  iconeSucesso: {
    width: 68,
    height: 68,
    borderRadius: 34,
    backgroundColor: cores.second,

    justifyContent: 'center',
    alignItems: 'center',

    marginBottom: 12,
  },

  check: {
    color: '#FFFFFF',
    fontSize: 40,
    fontWeight: 'bold',
  },

  titulo: {
    fontSize: 24,
    fontWeight: 'bold',
    color: cores.dark,
    textAlign: 'center',

    marginBottom: 5,
  },

  subtitulo: {
    fontSize: 13,
    color: cores.secondary,
    textAlign: 'center',

    marginBottom: 10,
  },

  numeroPedido: {
    fontSize: 15,
    fontWeight: 'bold',
    color: cores.primary,
  },

  // ==========================================
  // CARDS
  // ==========================================

  card: {
    backgroundColor: '#FFFFFF',

    borderRadius: 14,

    padding: 17,

    marginBottom: 14,

    elevation: 2,

    shadowColor: '#000000',

    shadowOffset: {
      width: 0,
      height: 2,
    },

    shadowOpacity: 0.08,

    shadowRadius: 4,
  },

  tituloCard: {
    fontSize: 17,
    fontWeight: 'bold',

    color: cores.dark,

    marginBottom: 15,
  },

  // ==========================================
  // PRODUTOS
  // ==========================================

  item: {
    flexDirection: 'row',

    justifyContent: 'space-between',

    alignItems: 'center',

    paddingVertical: 5,
  },

  itemEsquerda: {
    flex: 1,

    paddingRight: 10,
  },

  nomeItem: {
    fontSize: 14,

    color: cores.dark,

    fontWeight: '500',
  },

  precoItem: {
    fontSize: 14,

    color: cores.dark,

    fontWeight: '600',
  },

  // ==========================================
  // VALORES
  // ==========================================

  divisor: {
    height: 1,

    backgroundColor: '#E5E7EB',

    marginVertical: 12,
  },

  linhaValor: {
    flexDirection: 'row',

    justifyContent: 'space-between',

    alignItems: 'center',

    paddingVertical: 3,
  },

  labelValor: {
    fontSize: 13,

    color: cores.secondary,
  },

  valor: {
    fontSize: 13,

    color: cores.dark,
  },

  totalContainer: {
    flexDirection: 'row',

    justifyContent: 'space-between',

    alignItems: 'center',

    paddingTop: 2,
  },

  totalLabel: {
    fontSize: 17,

    fontWeight: 'bold',

    color: cores.dark,
  },

  totalValor: {
    fontSize: 18,

    fontWeight: 'bold',

    color: cores.second,
  },

  // ==========================================
  // ENTREGA
  // ==========================================

  label: {
    fontSize: 12,

    color: cores.secondary,

    marginBottom: 5,
  },

  informacao: {
    fontSize: 14,

    color: cores.dark,

    lineHeight: 20,

    marginBottom: 12,
  },

  // ==========================================
  // PAGAMENTO
  // ==========================================

  pagamentoLinha: {
    flexDirection: 'row',

    justifyContent: 'space-between',

    alignItems: 'center',

    marginBottom: 5,
  },

  pagamento: {
    fontSize: 14,

    fontWeight: '600',

    color: cores.dark,

    textAlign: 'right',
  },

  // ==========================================
  // BOTÃO
  // ==========================================

  botao: {
    backgroundColor: cores.primary,

    borderRadius: 12,

    minHeight: 52,

    justifyContent: 'center',

    alignItems: 'center',

    marginTop: 3,
  },

  textoBotao: {
    color: '#FFFFFF',

    fontSize: 15,

    fontWeight: 'bold',
  },

  // ==========================================
  // RODAPÉ
  // ==========================================

  rodape: {
    textAlign: 'center',

    fontSize: 12,

    color: cores.secondary,

    marginTop: 12,
  },

  // ==========================================
  // ERRO
  // ==========================================

  erroContainer: {
    flex: 1,

    backgroundColor: cores.background,

    justifyContent: 'center',

    alignItems: 'center',

    padding: 20,
  },

  erroTitulo: {
    fontSize: 20,

    fontWeight: 'bold',

    color: cores.dark,

    marginBottom: 20,

    textAlign: 'center',
  },

});