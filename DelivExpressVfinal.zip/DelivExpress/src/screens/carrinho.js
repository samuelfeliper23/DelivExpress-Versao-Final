import React from 'react';

import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
} from 'react-native';

import cores from '../styles/cores';

function Carrinho({
  carrinho,
  aumentarQtd,
  diminuirQtd,
  voltarCardapio,
  continuarCheck,
}) {
  const subtotal = carrinho.reduce(
    (total, item) => total + item.preco * item.quantidade,
    0
  );

  const taxaEntrega = 6;

  const total = subtotal + taxaEntrega;

  return (
    <View style={styles.container}>

      {/* CABEÇALHO */}
      <View style={styles.header}>

        <TouchableOpacity
          style={styles.backButton}
          onPress={voltarCardapio}
        >
          <Text style={styles.backText}>←</Text>
        </TouchableOpacity>

        <Text style={styles.headerTitle}>
          Meu Carrinho
        </Text>

      </View>


      {/* LISTA DOS PRODUTOS */}
      <ScrollView
        style={styles.lista}
        contentContainerStyle={styles.listaContent}
      >

        {carrinho.length === 0 ? (

          <View style={styles.emptyContainer}>

            <Text style={styles.emptyText}>
              Seu carrinho está vazio.
            </Text>

            <TouchableOpacity
              style={styles.voltarButton}
              onPress={voltarCardapio}
            >
              <Text style={styles.voltarButtonText}>
                Voltar ao cardápio
              </Text>
            </TouchableOpacity>

          </View>

        ) : (

          carrinho.map((item) => (

            <View
              key={item.id}
              style={styles.item}
            >

              {/* INFORMAÇÕES */}
              <View style={styles.info}>

                <Text style={styles.name}>
                  {item.nome}
                </Text>

                <Text style={styles.price}>
                  R$ {item.preco.toFixed(2).replace('.', ',')}
                </Text>

              </View>


              {/* CONTROLES + TOTAL DO ITEM */}
              <View style={styles.rightSide}>

                <View style={styles.quantityContainer}>

                  <TouchableOpacity
                    style={styles.quantityButton}
                    onPress={() => diminuirQtd(item.id)}
                  >
                    <Text style={styles.quantityButtonText}>
                      −
                    </Text>
                  </TouchableOpacity>


                  <Text style={styles.quantity}>
                    {item.quantidade}
                  </Text>


                  <TouchableOpacity
                    style={styles.quantityButton}
                    onPress={() => aumentarQtd(item.id)}
                  >
                    <Text style={styles.quantityButtonText}>
                      +
                    </Text>
                  </TouchableOpacity>

                </View>


                <Text style={styles.itemTotal}>
                  R$ {(item.preco * item.quantidade)
                    .toFixed(2)
                    .replace('.', ',')}
                </Text>

              </View>

            </View>

          ))

        )}

      </ScrollView>


      {/* ÁREA INFERIOR */}
      <View style={styles.bottomArea}>

        {/* RESUMO */}
        <View style={styles.summary}>

          <View style={styles.summaryRow}>

            <Text style={styles.summaryLabel}>
              Subtotal
            </Text>

            <Text style={styles.summaryValue}>
              R$ {subtotal.toFixed(2).replace('.', ',')}
            </Text>

          </View>


          <View style={styles.summaryRow}>

            <Text style={styles.summaryLabel}>
              Entrega
            </Text>

            <Text style={styles.summaryValue}>
              R$ {taxaEntrega.toFixed(2).replace('.', ',')}
            </Text>

          </View>


          <View style={styles.totalRow}>

            <Text style={styles.totalLabel}>
              TOTAL
            </Text>

            <Text style={styles.total}>
              R$ {total.toFixed(2).replace('.', ',')}
            </Text>

          </View>

        </View>


        {/* BOTÃO CONTINUAR */}
        <TouchableOpacity
          style={[
            styles.continueButton,
            carrinho.length === 0 &&
              styles.continueButtonDisabled,
          ]}
          onPress={continuarCheck}
          disabled={carrinho.length === 0}
        >

          <Text style={styles.continueButtonText}>
            Continuar
          </Text>

        </TouchableOpacity>

      </View>

    </View>
  );
}


const styles = StyleSheet.create({

  /* TELA */
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },


  /* HEADER */
  header: {
    height: 72,
    backgroundColor: cores.primary,

    flexDirection: 'row',
    alignItems: 'center',

    paddingHorizontal: 18,

    borderBottomLeftRadius: 8,
    borderBottomRightRadius: 8,
  },

  backButton: {
    width: 44,
    height: 44,

    justifyContent: 'center',
    alignItems: 'center',

    marginRight: 6,
  },

  backText: {
    color: '#FFFFFF',
    fontSize: 28,
    fontWeight: '500',
  },

  headerTitle: {
    color: '#FFFFFF',
    fontSize: 21,
    fontWeight: 'bold',
  },


  /* LISTA */
  lista: {
    flex: 1,
  },

  listaContent: {
    paddingHorizontal: 18,
    paddingTop: 14,
    paddingBottom: 20,
  },


  /* ITEM */
  item: {
    minHeight: 88,

    flexDirection: 'row',
    alignItems: 'center',

    borderBottomWidth: 1,
    borderBottomColor: '#E5E5E5',

    paddingVertical: 14,
  },

  info: {
    flex: 1,
    justifyContent: 'center',
  },

  name: {
    color: cores.dark,
    fontSize: 17,
    fontWeight: 'bold',

    marginBottom: 7,
  },

  price: {
    color: cores.secondary,
    fontSize: 14,
  },


  /* LADO DIREITO */
  rightSide: {
    alignItems: 'flex-end',
    marginLeft: 10,
  },

  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  quantityButton: {
    width: 38,
    height: 38,

    borderRadius: 8,

    borderWidth: 2,
    borderColor: cores.primary,

    justifyContent: 'center',
    alignItems: 'center',

    backgroundColor: '#FFFFFF',
  },

  quantityButtonText: {
    color: cores.primary,
    fontSize: 22,
    fontWeight: 'bold',
  },

  quantity: {
    width: 32,

    textAlign: 'center',

    color: cores.dark,
    fontSize: 16,
    fontWeight: 'bold',
  },

  itemTotal: {
    color: cores.dark,
    fontSize: 15,
    fontWeight: 'bold',

    marginTop: 5,
  },


  /* CARRINHO VAZIO */
  emptyContainer: {
    alignItems: 'center',
    paddingTop: 40,
  },

  emptyText: {
    color: cores.secondary,
    fontSize: 16,

    marginBottom: 20,
  },

  voltarButton: {
    minHeight: 44,

    paddingHorizontal: 20,

    borderRadius: 8,

    backgroundColor: cores.primary,

    justifyContent: 'center',
    alignItems: 'center',
  },

  voltarButtonText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: 'bold',
  },


  /* ÁREA INFERIOR */
  bottomArea: {
    backgroundColor: '#FFFFFF',

    paddingHorizontal: 18,
    paddingTop: 10,
    paddingBottom: 16,
  },


  /* CARD DO RESUMO */
  summary: {
    backgroundColor: cores.background,

    borderRadius: 14,

    paddingHorizontal: 18,
    paddingVertical: 14,

    marginBottom: 12,
  },

  summaryRow: {
    flexDirection: 'row',

    justifyContent: 'space-between',
    alignItems: 'center',

    marginBottom: 8,
  },

  summaryLabel: {
    color: cores.secondary,
    fontSize: 15,
  },

  summaryValue: {
    color: cores.secondary,
    fontSize: 15,
  },


  /* TOTAL */
  totalRow: {
    flexDirection: 'row',

    justifyContent: 'space-between',
    alignItems: 'center',

    marginTop: 3,
  },

  totalLabel: {
    color: cores.dark,
    fontSize: 20,
    fontWeight: 'bold',
  },

  total: {
    color: cores.success,
    fontSize: 20,
    fontWeight: 'bold',
  },


  /* BOTÃO */
  continueButton: {
    height: 56,

    borderRadius: 10,

    backgroundColor: cores.primary,

    justifyContent: 'center',
    alignItems: 'center',
  },

  continueButtonDisabled: {
    opacity: 0.45,
  },

  continueButtonText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: 'bold',
  },

});

export default Carrinho;