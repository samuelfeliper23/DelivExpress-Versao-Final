import React, { useState } from 'react';
import { View, StyleSheet } from 'react-native';

import Cardapio from './src/screens/cardapio';
import Carrinho from './src/screens/carrinho';
import Checkout from './src/screens/checkout';
import Confirmacao from './src/screens/confirmacao';

import cores from './src/styles/cores';

export default function App() {
  // Tela atual
  const [tela, setTela] = useState('cardapio');

  // Produtos do carrinho
  const [carrinho, setCarrinho] = useState([]);

  // Dados do pedido finalizado
  const [pedido, setPedido] = useState(null);

  // =====================================================
  // CARRINHO
  // =====================================================

  const adicionarAoCarrinho = (produto) => {
    setCarrinho((carrinhoAtual) => {
      const produtoExistente = carrinhoAtual.find(
        (item) => item.id === produto.id
      );

      if (produtoExistente) {
        return carrinhoAtual.map((item) =>
          item.id === produto.id
            ? {
                ...item,
                quantidade: item.quantidade + 1,
              }
            : item
        );
      }

      return [
        ...carrinhoAtual,
        {
          ...produto,
          quantidade: 1,
        },
      ];
    });
  };

  const aumentarQtd = (id) => {
    setCarrinho((carrinhoAtual) =>
      carrinhoAtual.map((item) =>
        item.id === id
          ? {
              ...item,
              quantidade: item.quantidade + 1,
            }
          : item
      )
    );
  };

  const diminuirQtd = (id) => {
    setCarrinho((carrinhoAtual) =>
      carrinhoAtual
        .map((item) =>
          item.id === id
            ? {
                ...item,
                quantidade: item.quantidade - 1,
              }
            : item
        )
        .filter((item) => item.quantidade > 0)
    );
  };

  // =====================================================
  // NAVEGAÇÃO
  // =====================================================

  const irParaCarrinho = () => {
    setTela('carrinho');
  };

  const voltarCardapio = () => {
    setTela('cardapio');
  };

  const continuarCheck = () => {
    setTela('checkout');
  };

  const voltarCarrinho = () => {
    setTela('carrinho');
  };

  // =====================================================
  // FINALIZAR CHECKOUT
  // =====================================================

  const finalizarCheckout = (dadosPedido) => {
    // Gera um número aleatório de 4 dígitos
    const numeroPedido = Math.floor(
      1000 + Math.random() * 9000
    );

    const novoPedido = {
      ...dadosPedido,
      numeroPedido,
    };

    setPedido(novoPedido);

    // Vai para a tela T4
    setTela('confirmacao');
  };

  // =====================================================
  // NOVO PEDIDO
  // =====================================================

  const novoPedido = () => {
    setCarrinho([]);
    setPedido(null);
    setTela('cardapio');
  };

  // =====================================================
  // TELAS
  // =====================================================

  return (
    <View style={styles.container}>

      {tela === 'cardapio' && (
        <Cardapio
          carrinho={carrinho}
          adicionarAoCarrinho={adicionarAoCarrinho}
          irParaCarrinho={irParaCarrinho}
        />
      )}

      {tela === 'carrinho' && (
        <Carrinho
          carrinho={carrinho}
          voltarCardapio={voltarCardapio}
          continuarCheck={continuarCheck}
          aumentarQtd={aumentarQtd}
          diminuirQtd={diminuirQtd}
        />
      )}

      {tela === 'checkout' && (
        <Checkout
          carrinho={carrinho}
          voltarCarrinho={voltarCarrinho}
          finalizarCheckout={finalizarCheckout}
        />
      )}

      {tela === 'confirmacao' && (
        <Confirmacao
          pedido={pedido}
          carrinho={carrinho}
          novoPedido={novoPedido}
        />
      )}

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: cores.background,
  },
});